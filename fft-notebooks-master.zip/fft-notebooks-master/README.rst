===================================
`Fast Fourier Transform notebooks`_
===================================

Copyright (c) 2016 Jeremie DECOCK (http://www.jdhp.org)

* Source code: https://github.com/jdhp-docs/fft-notebooks

Description
===========

This repository contains a Jupyter notebook about Fourier transform with Numpy
and Scipy.

Installation and usage
======================

After you have cloned this repository in your computer, it is recommended to
add the https://github.com/jdhp-docs/notebook-skeleton submodule in a directory
named "ipynb"::

 git clone https://github.com/jdhp-docs/fft-notebooks.git
 cd python-notebooks
 git submodule add https://github.com/jdhp-docs/notebook-skeleton.git ipynb

License
=======

These notebooks are provided under the terms and conditions of the
`MIT License`_.


.. _MIT License: http://opensource.org/licenses/MIT
.. _Fast Fourier Transform notebooks: https://github.com/jdhp-docs/fft-notebooks

